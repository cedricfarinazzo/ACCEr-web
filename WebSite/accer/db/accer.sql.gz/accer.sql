-- Adminer 4.5.0 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `accer` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `accer`;

DROP TABLE IF EXISTS `authcookieremember`;
CREATE TABLE `authcookieremember` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ID_user` int(11) unsigned NOT NULL,
  `token` varchar(255) NOT NULL,
  `expire` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `authcookieremember`;
INSERT INTO `authcookieremember` (`ID`, `ID_user`, `token`, `expire`) VALUES
(4,	1,	'1=-=-934317f425843979fbd12a3e62ecd16caaafab8bd4ed0271abe3b80c9fd49537356a192b7913b04c54574d18c28d46e6395428ab',	1550438403);

DROP TABLE IF EXISTS `authsess`;
CREATE TABLE `authsess` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ID_user` int(11) unsigned NOT NULL,
  `token` varchar(255) NOT NULL,
  `IP` varchar(100) NOT NULL,
  `PHPSESSID` varchar(255) NOT NULL,
  `expire` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `authsess`;
INSERT INTO `authsess` (`ID`, `ID_user`, `token`, `IP`, `PHPSESSID`, `expire`) VALUES
(4,	1,	'1=-=-e76428e40175c55d3b493884d204111f3967ecd7ffd92fdbc58de83f07f3fa57356a192b7913b04c54574d18c28d46e6395428ab',	'88.139.79.108',	'4sj8i5uofd1m52lq0aiiq00tc7',	1519395812);

DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ID_user` int(10) unsigned NOT NULL,
  `content` varchar(255) NOT NULL,
  `date_post` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `chat`;

DROP TABLE IF EXISTS `erreurs`;
CREATE TABLE `erreurs` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `erreur` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `erreurs`;
INSERT INTO `erreurs` (`ID`, `erreur`) VALUES
(1,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767688'),
(2,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767688'),
(3,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767688'),
(4,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767700'),
(5,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767700'),
(6,	'[2] file_put_contents(/var/www/accer/.cache/source/source.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 58)  at 1517767700'),
(7,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767700'),
(8,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767700'),
(9,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767700'),
(10,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767704'),
(11,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767704'),
(12,	'[2] file_put_contents(/var/www/accer/.cache/report/report.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 58)  at 1517767704'),
(13,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767704'),
(14,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767704'),
(15,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767704'),
(16,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767706'),
(17,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767706'),
(18,	'[2] file_put_contents(/var/www/accer/.cache/progress/progress.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 58)  at 1517767706'),
(19,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767706'),
(20,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767707'),
(21,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767707'),
(22,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767800'),
(23,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767800'),
(24,	'[2] file_put_contents(/var/www/accer/.cache/progress/progress.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 58)  at 1517767800'),
(25,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767800'),
(26,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767800'),
(27,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767800'),
(28,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767804'),
(29,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767804'),
(30,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767804'),
(31,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767894'),
(32,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767894'),
(33,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767894'),
(34,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767897'),
(35,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767897'),
(36,	'[2] file_put_contents(/var/www/accer/.cache/download/download.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 58)  at 1517767897'),
(37,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767897'),
(38,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767898'),
(39,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767898'),
(40,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767902'),
(41,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767902'),
(42,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767902'),
(43,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767905'),
(44,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767905'),
(45,	'[2] file_put_contents(/var/www/accer/.cache/project/project.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 58)  at 1517767905'),
(46,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767905'),
(47,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767905'),
(48,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767905'),
(49,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767907'),
(50,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767907'),
(51,	'[2] file_put_contents(/var/www/accer/.cache/progress/progress.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 58)  at 1517767907'),
(52,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767907'),
(53,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767907'),
(54,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767907'),
(55,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767909'),
(56,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767909'),
(57,	'[2] file_put_contents(/var/www/accer/.cache/download/download.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 58)  at 1517767909'),
(58,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767909'),
(59,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767909'),
(60,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767909'),
(61,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767930'),
(62,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767930'),
(63,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767930'),
(64,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767950'),
(65,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767950'),
(66,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767950'),
(67,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767952'),
(68,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767952'),
(69,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767952'),
(70,	'[2] mkdir(): Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 14)  at 1517767982'),
(71,	'[2] mkdir(): No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 53)  at 1517767982'),
(72,	'[2] file_put_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1517767982'),
(73,	'[2] session_regenerate_id(): Cannot regenerate session id - session is not active\nFichier : /var/www/accer/class/UserManager.php (ligne 85)  at 1517770203'),
(74,	'[2] fopen(/var/www/accer/data/maintenance.tmp): failed to open stream: Permission denied\nFichier : /var/www/accer/function/maintenance.php (ligne 45)  at 1517791117'),
(75,	'[2] fopen(/var/www/accer/data/maintenance.tmp): failed to open stream: Permission denied\nFichier : /var/www/accer/function/maintenance.php (ligne 45)  at 1517791143'),
(76,	'[2] fopen(/var/www/accer/data/maintenance.tmp): failed to open stream: Permission denied\nFichier : /var/www/accer/function/maintenance.php (ligne 45)  at 1517791150'),
(77,	'[2] fopen(/var/www/accer/data/maintenance.tmp): failed to open stream: Permission denied\nFichier : /var/www/accer/function/maintenance.php (ligne 45)  at 1517791211'),
(78,	'[2] fopen(/var/www/accer/data/maintenance.tmp): failed to open stream: Permission denied\nFichier : /var/www/accer/function/maintenance.php (ligne 45)  at 1517791437'),
(79,	'[8] Undefined index: _admin_maj\nFichier : /var/www/accer/public/index.php (ligne 13)  at 1517791567'),
(80,	'[2] move_uploaded_file(/var/www/accer/data/shadowminer/report/CahierDesCharges_ACCEr.pdf): failed to open stream: Permission denied\nFichier : /var/www/accer/class/PdfManager.php (ligne 37)  at 1517791825'),
(81,	'[2] move_uploaded_file(): Unable to move \'/tmp/phpjwoOxF\' to \'/var/www/accer/data/shadowminer/report/CahierDesCharges_ACCEr.pdf\'\nFichier : /var/www/accer/class/PdfManager.php (ligne 37)  at 1517791825'),
(82,	'[2] file_get_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 42)  at 1517830274'),
(83,	'[2] file_get_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 42)  at 1517830275'),
(84,	'[2] file_get_contents(/var/www/accer/.cache/report/report.cache): failed to open stream: Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 44)  at 1517830285'),
(85,	'[2] file_get_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 42)  at 1517830285'),
(86,	'[2] file_get_contents(/var/www/accer/.cache/image/1=-=e7d77248ba895137ce6e4b697bc30ed252fba4a7-90.cache): failed to open stream: Permission denied\nFichier : /var/www/accer/class/CacheManager.php (ligne 42)  at 1517830287'),
(87,	'[2] readfile(/var/www/accer/data/shadowminer/report/CahierDesCharges_ACCEr.pdf): failed to open stream: Permission denied\nFichier : /var/www/accer/class/PdfManager.php (ligne 109)  at 1517830299'),
(88,	'[2] getimagesize(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 133)  at 1517857719'),
(89,	'[2] imagecreatefrompng(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 110)  at 1517857719'),
(90,	'[2] getimagesize(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 116)  at 1517857719'),
(91,	'[2] Division by zero\nFichier : /var/www/accer/class/ImageManager.php (ligne 117)  at 1517857719'),
(92,	'[2] imagecreatetruecolor() expects parameter 2 to be integer, float given\nFichier : /var/www/accer/class/ImageManager.php (ligne 118)  at 1517857719'),
(93,	'[2] getimagesize(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 133)  at 1517857720'),
(94,	'[2] imagecreatefrompng(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 110)  at 1517857720'),
(95,	'[2] getimagesize(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 116)  at 1517857720'),
(96,	'[2] Division by zero\nFichier : /var/www/accer/class/ImageManager.php (ligne 117)  at 1517857720'),
(97,	'[2] imagecreatetruecolor() expects parameter 2 to be integer, float given\nFichier : /var/www/accer/class/ImageManager.php (ligne 118)  at 1517857720'),
(98,	'[2] getimagesize(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 133)  at 1517857722'),
(99,	'[2] imagecreatefrompng(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 110)  at 1517857722'),
(100,	'[2] getimagesize(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 116)  at 1517857722'),
(101,	'[2] Division by zero\nFichier : /var/www/accer/class/ImageManager.php (ligne 117)  at 1517857722'),
(102,	'[2] imagecreatetruecolor() expects parameter 2 to be integer, float given\nFichier : /var/www/accer/class/ImageManager.php (ligne 118)  at 1517857722'),
(103,	'[2] getimagesize(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 133)  at 1517857722'),
(104,	'[2] imagecreatefrompng(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 110)  at 1517857722'),
(105,	'[2] getimagesize(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 116)  at 1517857722'),
(106,	'[2] Division by zero\nFichier : /var/www/accer/class/ImageManager.php (ligne 117)  at 1517857722'),
(107,	'[2] imagecreatetruecolor() expects parameter 2 to be integer, float given\nFichier : /var/www/accer/class/ImageManager.php (ligne 118)  at 1517857722'),
(108,	'[2] getimagesize(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 133)  at 1517857723'),
(109,	'[2] imagecreatefrompng(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 110)  at 1517857723'),
(110,	'[2] getimagesize(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 116)  at 1517857723'),
(111,	'[2] Division by zero\nFichier : /var/www/accer/class/ImageManager.php (ligne 117)  at 1517857723'),
(112,	'[2] imagecreatetruecolor() expects parameter 2 to be integer, float given\nFichier : /var/www/accer/class/ImageManager.php (ligne 118)  at 1517857723'),
(113,	'[2] getimagesize(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 133)  at 1517857723'),
(114,	'[2] imagecreatefrompng(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 110)  at 1517857723'),
(115,	'[2] getimagesize(/var/www/accer/data/image/accer_logo.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 116)  at 1517857723'),
(116,	'[2] Division by zero\nFichier : /var/www/accer/class/ImageManager.php (ligne 117)  at 1517857723'),
(117,	'[2] imagecreatetruecolor() expects parameter 2 to be integer, float given\nFichier : /var/www/accer/class/ImageManager.php (ligne 118)  at 1517857723'),
(118,	'[2] move_uploaded_file(/var/www/accer/data/image//9c1b1bea2e87dda17c3f61075a70e9da9278249370ad7cfef2faba3c68c077077a1dd52d046385f27bc854d1390ab4a0cd571d58ba3205fd29dd02f1a3d3ed1d.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 71)  at 1517864155'),
(119,	'[2] move_uploaded_file(): Unable to move \'/tmp/php3bYLEZ\' to \'/var/www/accer/data/image//9c1b1bea2e87dda17c3f61075a70e9da9278249370ad7cfef2faba3c68c077077a1dd52d046385f27bc854d1390ab4a0cd571d58ba3205fd29dd02f1a3d3ed1d.png\'\nFichier : /var/www/accer/class/ImageManager.php (ligne 71)  at 1517864155'),
(120,	'[2] move_uploaded_file(/var/www/accer/data/image//380d57ac4f0d174a70cb5c48b8d88f09ee876b5fb818caaa713e1ba40f5d3c7867645c1e86473adf49c61b4519ef00a84112a60f6ae160e543236a55f8df002e.png): failed to open stream: Permission denied\nFichier : /var/www/accer/class/ImageManager.php (ligne 71)  at 1517864898'),
(121,	'[2] move_uploaded_file(): Unable to move \'/tmp/phpkPEZM5\' to \'/var/www/accer/data/image//380d57ac4f0d174a70cb5c48b8d88f09ee876b5fb818caaa713e1ba40f5d3c7867645c1e86473adf49c61b4519ef00a84112a60f6ae160e543236a55f8df002e.png\'\nFichier : /var/www/accer/class/ImageManager.php (ligne 71)  at 1517864898'),
(122,	'[8] Undefined index: _admin_maj\nFichier : /var/www/accer/public/index.php (ligne 13)  at 1518101289'),
(123,	'[8] Undefined index: _admin_maj\nFichier : /var/www/accer/public/index.php (ligne 13)  at 1518106802'),
(124,	'[8] Undefined offset: 1\nFichier : /var/www/accer/class/ImageManager.php (ligne 146)  at 1518620494'),
(125,	'[8] Undefined offset: 1\nFichier : /var/www/accer/class/ImageManager.php (ligne 146)  at 1518620504'),
(126,	'[8] Undefined offset: 1\nFichier : /var/www/accer/class/ImageManager.php (ligne 146)  at 1518620504'),
(127,	'[2] imagecreatetruecolor(): Invalid image dimensions\nFichier : /var/www/accer/class/ImageManager.php (ligne 118)  at 1518620527'),
(128,	'[2] file_exists() expects parameter 1 to be a valid path, string given\nFichier : /var/www/accer/class/CacheManager.php (ligne 24)  at 1518620534'),
(129,	'[8] Undefined offset: 1\nFichier : /var/www/accer/class/ImageManager.php (ligne 146)  at 1518620534'),
(130,	'[2] file_put_contents() expects parameter 1 to be a valid path, string given\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1518620534'),
(131,	'[2] imagecreatetruecolor(): Invalid image dimensions\nFichier : /var/www/accer/class/ImageManager.php (ligne 118)  at 1518620545'),
(132,	'[8] Undefined offset: 1\nFichier : /var/www/accer/class/ImageManager.php (ligne 146)  at 1518620546'),
(133,	'[2] imagecreatetruecolor(): Invalid image dimensions\nFichier : /var/www/accer/class/ImageManager.php (ligne 118)  at 1518620546'),
(134,	'[8] Undefined offset: 1\nFichier : /var/www/accer/class/ImageManager.php (ligne 146)  at 1518620548'),
(135,	'[2] file_put_contents(/var/www/accer/.cache/image/....//....//....//....//....//....//....//....//....//....//....//....//etc/passwd-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1518620548'),
(136,	'[8] Undefined offset: 1\nFichier : /var/www/accer/class/ImageManager.php (ligne 146)  at 1518620554'),
(137,	'[2] file_put_contents(/var/www/accer/.cache/image/C:/boot.ini-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1518620554'),
(138,	'[8] Undefined offset: 1\nFichier : /var/www/accer/class/ImageManager.php (ligne 146)  at 1518620554'),
(139,	'[2] imagecreatetruecolor(): Invalid image dimensions\nFichier : /var/www/accer/class/ImageManager.php (ligne 118)  at 1518620554'),
(140,	'[8] Undefined offset: 1\nFichier : /var/www/accer/class/ImageManager.php (ligne 146)  at 1518620554'),
(141,	'[8] Undefined offset: 1\nFichier : /var/www/accer/class/ImageManager.php (ligne 146)  at 1518620554'),
(142,	'[2] file_put_contents(/var/www/accer/.cache/image/file:/C:/boot.ini-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1518620554'),
(143,	'[2] imagecreatetruecolor(): Invalid image dimensions\nFichier : /var/www/accer/class/ImageManager.php (ligne 118)  at 1518620554'),
(144,	'[8] Undefined offset: 1\nFichier : /var/www/accer/class/ImageManager.php (ligne 146)  at 1518620554'),
(145,	'[8] Undefined offset: 1\nFichier : /var/www/accer/class/ImageManager.php (ligne 146)  at 1518620555'),
(146,	'[2] file_put_contents(/var/www/accer/.cache/image/file:/C:\\boot.ini-90.cache): failed to open stream: No such file or directory\nFichier : /var/www/accer/class/CacheManager.php (ligne 56)  at 1518620555'),
(147,	'[2] session_regenerate_id(): Cannot regenerate session id - session is not active\nFichier : /var/www/accer/class/UserManager.php (ligne 85)  at 1518899187'),
(148,	'[2] session_regenerate_id(): Cannot regenerate session id - session is not active\nFichier : /var/www/accer/class/UserManager.php (ligne 85)  at 1518902377');

DROP TABLE IF EXISTS `image`;
CREATE TABLE `image` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hash` varchar(255) NOT NULL,
  `path` text NOT NULL,
  `extension` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `image`;
INSERT INTO `image` (`ID`, `hash`, `path`, `extension`) VALUES
(1,	'e7d77248ba895137ce6e4b697bc30ed252fba4a7',	'/var/www/accer/data/image/accer_logo.png',	'png'),
(2,	'531397f92e7dd28aeb2b92d6ffe3fed4192693d7',	'/var/www/accer/data/image/avatar_defaut.jpg',	'jpg'),
(3,	'ff38476159937cb1c6fe383711c498cf5bff6a5d',	'/var/www/accer/data/image//9c1b1bea2e87dda17c3f61075a70e9da9278249370ad7cfef2faba3c68c077077a1dd52d046385f27bc854d1390ab4a0cd571d58ba3205fd29dd02f1a3d3ed1d.png',	'png'),
(4,	'4fac303328606e82818cba668cbb4db2214797e6',	'/var/www/accer/data/image//380d57ac4f0d174a70cb5c48b8d88f09ee876b5fb818caaa713e1ba40f5d3c7867645c1e86473adf49c61b4519ef00a84112a60f6ae160e543236a55f8df002e.png',	'png'),
(5,	'fbef60e3d37544f0752e40f97dc9ff3b21d2f608',	'/var/www/accer/data/image//2a8d9604f04d2fe69384ccf60fa12c88a169fb0a2863410989c9b0c90e45ec2ce4441dc5dc92b268713fc38c6922e58b3e350c84182577301a4c79f3b94a52b6.png',	'png'),
(6,	'28099b3bd0638bc11d6bcf968c4cccb98d11522e',	'/var/www/accer/data/image//ca29a660098a38cbe7fac04d752256e311ffe48c024c273a0429a2cca75d6e87a0cdc860e725c1fb36d65b49a47a5548e3a5bfdae6fba4822c6fff05c8bd7baf.jpg',	'jpg');

DROP TABLE IF EXISTS `pdf`;
CREATE TABLE `pdf` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hash` varchar(255) NOT NULL,
  `path` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `pdf`;
INSERT INTO `pdf` (`ID`, `hash`, `path`) VALUES
(2,	'02a9e44065e64ce4d9a488c04a760c6957f14215',	'/var/www/accer/data/shadowminer/report/CahierDesCharges_ACCEr_v2.pdf');

DROP TABLE IF EXISTS `progress`;
CREATE TABLE `progress` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_user` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `date_created` datetime NOT NULL,
  `etat` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `progress`;
INSERT INTO `progress` (`ID`, `ID_user`, `titre`, `description`, `date_created`, `etat`) VALUES
(1,	1,	'Site Web',	'Création des pages et de l\'api',	'2018-02-05 01:51:20',	75),
(2,	1,	'Mise en place du serveur',	'sur raspberry pi 3B:\r\n- installation serveur et base de données\r\n- création d\'un compte no-ip avec un sous domaine (accer.ddns.net)',	'2018-02-05 01:51:54',	100),
(3,	1,	'Préfabs de map',	'porte, sol, porte, flamme ...',	'2018-02-21 17:04:57',	40),
(4,	1,	'Préfabs joueurs',	'pour le solo et le multi',	'2018-02-21 17:07:52',	10);

DROP TABLE IF EXISTS `report`;
CREATE TABLE `report` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ID_user` int(10) unsigned NOT NULL,
  `titre` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `date_created` datetime NOT NULL,
  `pdf_content` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `report`;
INSERT INTO `report` (`ID`, `ID_user`, `titre`, `description`, `date_created`, `pdf_content`) VALUES
(3,	1,	'Cahier des Charges ACCEr',	'Voici le cahier des charges du groupe ACCEr pour le projet de S2 à EPITTA.\r\nLe dévellopement du jeu Shadow Miner pourra être suivi sur ce site.\r\n\r\nACCEr',	'2018-02-16 20:47:25',	'2');

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `date_register` datetime NOT NULL,
  `avatar_path` varchar(255) DEFAULT '2',
  `description` text,
  `rank` enum('user','admin','webmaster') NOT NULL DEFAULT 'user',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `user`;
INSERT INTO `user` (`ID`, `name`, `firstname`, `email`, `pass`, `date_register`, `avatar_path`, `description`, `rank`) VALUES
(1,	'FARINAZZO',	'Cédric',	'cedric.farinazzo@epita.fr',	'a99885e8ab226ebf4604b741113db99dd9c3ff8097301f143cd9bca32bd5bfc232007d851d2ecd0936ff0e7504551f28d45867b7b291acff506518c5a406872c',	'2018-02-16 19:18:55',	'5',	'chef de projet',	'webmaster'),
(2,	'Claudel',	'Antoine',	'antoine.claudel@hotmail.fr',	'c1f7b255974d4138524754937a79ae3bbc705ddf579ff4679cc48ecaf348610b4ddafc4bade4f22bf81c411b11b6232f85113237c6a2fb7d645b09e4063e48a1',	'2018-02-23 14:07:41',	'6',	'Le plus beau des beau gosses sur Terre',	'admin');

-- 2018-02-23 13:27:12
